# Crypto Challenges

## Challenge 1 – the Caesar cipher
Your challenge is to decipher this string: MYXQBKDEVKDSYXC

## Challenge 2 – base64

Decode this: VGhpcyBpcyB0b28gZWFzeQ==

## Challenge 2.1 - base64

Decode this: VWtkc2EwbEliSFprVTBjeFl6lZaMWxUUW5OaU1qbDNVSGM5UFFvPQo=

Hint: several rounds of Base64 were used. 

## Challenge 3 – XOR

### The first challenge is here:

Decipher this: kquht}

Key is a single digit

###  Here's a longer example that is in a hexadecimal format:

Decipher this: 70155d5c45415d5011585446424c

Key is two digits of ASCII

